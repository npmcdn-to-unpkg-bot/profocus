@extends('template')
@section('title')
    @foreach( $page as $info )
        {{ $info['title'] }}
    @endforeach
@stop
@section('content')
    <? if( request()->route()->getName() != 'home' ) echo '<div class="offset" style="padding-top: 90px;"></div>'; ?>
    <div class="light-wrapper">
        <div class="container inner">
            <!-- <h3 class="section-title">фотографы</h3>
            <div class="hr5" style="margin-top: 20px; margin-bottom: 50px;"></div> -->
            <!-- /.thin -->
            <div class="row">
                @foreach( $page as $info )
                <div class="col-sm-4">
                    <div class="caption-overlay">
                        <figure><a href="#"><img src="{{ url($info['thumbnail']) }}" alt="" /> </a></figure>
                        <div class="caption bottom-right">
                            <div class="title">
                                <h3 class="main-title layer">{{ $info['title'] }}</h3>
                            </div>
                            <!--/.title -->
                        </div>
                        <!--/.caption -->
                    </div>
                </div>
                <div class="col-sm-8">
                    {!! $info['body'] !!}
                </div>
                <!-- /column -->
                    @endforeach

            </div>


        </div>
        <!-- /.container -->
    </div>
    <!-- /.light-wrapper -->

    <div class="dark-wrapper">
        <div class="container inner">
            <!-- <h3 class="section-title">фотографы</h3>
            <div class="hr5" style="margin-top: 20px; margin-bottom: 50px;"></div> -->
            <!-- /.thin -->
            <div class="row">
                <div class="col-sm-12">
                    <form action="" id="reservedData">
                        <input type="text" id="datetimepicker" />
                        <br>
                        <input type="text" placeholder="МЯ" name="name">

                    </form>


                </div>
                <!-- /column -->

                <div class="col-sm-12">
                    <button id="add-data">Добавить</button>
                    <button id="send-data">go</button>
                    <ul id="reserved-dates">
                    </ul>
            </div>
            </div>
            <!-- /.row -->


        </div>
        <!-- /.container -->
    </div>
    <!-- /.light-wrapper -->


    <div class="ligh-wrapper">
        <div class="container inner">

            <!-- /.thin -->
            <div class="row">
                @foreach( $locations as $location )
                <div class="col-sm-4">
                    <div class="caption-overlay">
                        <figure><a href="{{ url('/rent',$location['id']) }}"><img src="{{ url($location['thumbnail']) }}" alt="" /></a></figure>
                        <div class="caption bottom-right">
                            <div class="title">
                                <h3 class="main-title layer">{{ $location['title'] }}</h3>
                            </div>
                            <!--/.title -->
                        </div>
                        <!--/.caption -->
                    </div>
                </div>
                @endforeach
                <!-- /column -->

            </div>
            <!-- /.row -->

        </div>
        <!-- /.container -->
    </div>
    <!-- /.light-wrapper -->

    <div class="dark-wrapper">
        <div class="container inner">
            <!-- <h3 class="section-title">фотографы</h3>
            <div class="hr5" style="margin-top: 20px; margin-bottom: 50px;"></div> -->
            <!-- /.thin -->
            <div class="row">
                @foreach( $stuff as $stuffy )
                    <div class="col-sm-12">
                        <h3 class="section-title">{{$stuffy['title']}}</h3>
                        {!! $stuffy['body'] !!}
                    </div>
                @endforeach
                <!-- /column -->
            </div>
            <!-- /.row -->
            <div class="carousel-wrapper">
                <div class="carousel carousel-boxed blog">

                 @foreach( $equipment as $ec)

                    <div class="item post">
                        <figure class="main"><img src="{{ url($ec['thumbnail'])  }}" alt="" /></figure>
                        <div class="box text-center">
                            <h4 class="post-title"><a href="">{{ $ec['title']  }}</a></h4>
                        </div>
                        <!-- /.box -->

                    </div>
                    <!-- /.post -->
                    @endforeach

                </div>
                <!--/.carousel -->
            </div>
            <!--/.carousel-wrapper -->
        </div>
        <!-- /.container -->
    </div>
    <!-- /.light-wrapper -->

    <script type='text/javascript'>
       <?
        $js_array = json_encode($json);
        echo "var reservedDates = ". $js_array . ";\n";
        ?>
    </script>



@stop

@section('footer')

    <script>

        $(document).ready( function(){
            $('#datetimepicker').datetimepicker({
                format:'d.m.Y H:i',
                inline:true,
                lang:'ru',
                onGenerate: setDefaultDates,
                onSelectDate: selectDates,
                onSelectTime: selectTime,
                minDate: returnYesterday(),
                disabledDates: ['03.05.2016'],
                formatDate:'d.m.Y',
                defaultSelect: false

            });
/*            var interval = setInterval(function () {
                if ($(".xdsoft_datetimepicker").length) {


                    setDefaultDates();

                    clearInterval(interval);

                }
            }, 300);*/


            $('#add-data').on( 'click', addData);
            $("#send-data").on('click',sendData);

            /*
             $('body').on('click', '.xdsoft_current', function(){
             event.preventDefault();
             $(this).toggleClass('xdsoft_current');
             //$(this).toggleClass("xdsoft_current")
             //$(this).removeClass('xdsoft_current');
             /!*$('.xdsoft_calendar .xdsoft_time').removeClass('xdsoft_current');*!/
             })
             */

            $('body').on('click', '.xdsoft_current', function(){
                alert('currentDateTime');
            });

        } );

     var Orders = {
         getReservedData: function (container){
            var data = {};
              container.each(function(i){
                  var self= $( this );
                  data[i] = self.text();
              });
            return data;
         },
        sendData: function(){
            var reverved = Orders.getReservedData( $('#reserved-dates li') );
            $.ajax({
                type: 'POST',
                url: 'rent',
                data: reverved,
                success: function(data){

                    alert("reservedData success");

                },
                error: function (data) {
                    alert("reservedData error");
                },
                beforeSend: function (xhr) {
                    var token = $('meta[name="csrf_token"]').attr('content');

                    if (token) {
                        return xhr.setRequestHeader('X-CSRF-TOKEN', token);
                    }
                }
            });
        },

        addData: function (){

            var day = $('.xdsoft_calendar .xdsoft_current');
            var hour = $('.xdsoft_calendar .xdsoft_time');

            if ( !(day.hasClass('hasReserved')) && !(hour.hasClass('hasReserved')) ){
                day.addClass('hasReserved');
                hour.addClass('hasReserved');
                $('#reserved-dates').append('<li>' +  $(awesomeDatpicker).val() + '</li>');
            }

        }
    };




        var targetDay = 0;
        targetHours = false;
        var targetHoursData;
        var orders = [];
        function selectDates(){
                var target = $(event.target).parent();
                if ( target.data('date') != targetDay ){
                    targetDay = target.data('date');
                } else {
                    targetDay = 0;
                }
            if (target.hasClass('bronned')){
                targetHours = true;
            }
        }


        function selectTime(){
            var target = $(event.target).data('hour');
            targetHoursData = target;
        }


        function setDefaultDates(){

            var days = [];
            var currentReservedDates = $.parseJSON(reservedDates);

            var currentData = $('#datetimepicker').datetimepicker('getValue');

            var currentMonth =  currentData.getMonth() + 1;

            var currentDay =  currentData.getDate();

            for (i=0; i<currentReservedDates.length; i++){
                if ( currentReservedDates[i].month == currentMonth ){
                    days.push(currentReservedDates[i].day);
                    $('[data-date=' + currentReservedDates[i].day + ']').addClass('bronned');
                }
            }

            $('.xdsoft_current').removeClass('xdsoft_current');




            if ( targetDay != 0 ) {
                targetCell =  $('[data-date=' + targetDay + ']');
                if ( targetCell.hasClass('selected') ){
                    targetCell.removeClass('selected');
                    $('.xdsoft_time_variant .selected').removeClass('selected');
                } else {
                    $('.selected').removeClass('selected');
                    targetCell.addClass('selected');
                    if ( targetHours ) {
                        var targetHoursArr = [];
                        for (i=0; i<currentReservedDates.length; i++){
                            if ( currentReservedDates[i].month == currentMonth ){

                                if ( currentReservedDates[i].day == currentDay ){
                                    targetHoursArr.push(currentReservedDates[i].id);
                                    $('[data-date=' + currentReservedDates[i].day + ']').addClass('bronned');
                                    }
                            }
                        }

                        for (i=0; i<targetHoursArr.length; i++){
                            $('[data-hour=' + targetHoursArr[i] + ']').addClass('bronned');
                        }


                    } else {
                        $('.xdsoft_time.selected').removeClass('selected');
                    }}
                }

//            $('.xdsoft_time_variant .bronned').removeClass('bronned');
            var targetHour = $('[data-hour=' + targetHoursData + ']');

            targetHour.toggleClass('bronned');

        }

        function returnYesterday(){
            var today = new Date();
            var dd = today.getDate();

            var mm = today.getMonth()+1; //January is 0!

            var yyyy = today.getFullYear();
            if(dd<10){
                dd='0'+dd
            }
            if(mm<10){
                mm='0'+mm
            }
            var today = dd+'.'+mm+'.'+yyyy;
            return today;
        }





        var logic = function( currentDateTime ){

            var calendar = $('.xdsoft_calendar .xdsoft_current');
            var time = $('.xdsoft_time_variant .xdsoft_current');
            alert('HELLO');
            if ( !!time.length && !!calendar.length ){
                alert('HAVE');
                calendar.removeClass('xdsoft_current');
                time.removeClass('xdsoft_current');
            }
//                event.preventDefault();
        };



    </script>

    <style>
    .bronned{
        background-color: pink!important;
        color: #000!important;
    }

    .selected{
        background-color: #0fd!important;
    }

    </style>


@stop